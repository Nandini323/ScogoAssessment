package com.example.scogoassessment

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

data class DemoData(
    var  id: String,
var name: String,
var symbol: String,
var rank: Int,
var is_new: Boolean,
var is_active: Boolean,
var type: String



// var   market_cap_usd: Long,
// var    volume_24h_usd: Long,
// var      bitcoin_dominance_percentage:Float,
// var      cryptocurrencies_number: Long,
// var      market_cap_ath_value: Long,
// var      market_cap_ath_date: String,
// var      volume_24h_ath_value: Long,
// var       volume_24h_ath_date:String,
// var      market_cap_change_24h: Float,
// var     volume_24h_change_24h: Float,
// var     last_updated: Long
)
const val BASE_URL = "https://api.coinpaprika.com/v1/"

interface DataRequest{
    @GET("coins")
    suspend fun getdatas():List<DemoData>

    companion object{
        var datarequest:DataRequest?=null
        fun getInstance():DataRequest{
            if(datarequest==null){
                datarequest=Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build().create(DataRequest::class.java)
            }
            return datarequest!!
        }
    }
}
